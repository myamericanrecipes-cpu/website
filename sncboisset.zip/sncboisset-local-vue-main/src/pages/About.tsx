import aboutImg from "@/assets/about-store.jpg";
import { Heart, Users, Award } from "lucide-react";

const About = () => {
  return (
    <div className="min-h-screen pt-28 pb-20">
      <div className="container mx-auto px-4">
        <h1 className="text-5xl font-bold text-center mb-4 text-foreground">À Propos</h1>
        <p className="text-center text-muted-foreground mb-12 text-lg">
          L'histoire de SNCBOISSET, votre commerce de proximité
        </p>

        {/* Hero Image */}
        <div className="mb-16 rounded-xl overflow-hidden shadow-xl">
          <img
            src={aboutImg}
            alt="Intérieur du magasin SNCBOISSET"
            className="w-full h-[400px] object-cover"
          />
        </div>

        {/* Notre Histoire */}
        <section className="mb-16 max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-primary">Notre Histoire</h2>
          <div className="space-y-4 text-lg text-muted-foreground">
            <p>
              SNCBOISSET est née de la passion pour la bonne cuisine et le commerce de proximité.
              Implantée au cœur d'Épinal, notre entreprise familiale s'est donnée pour mission
              de proposer des produits frais et des préparations maison à tous nos clients.
            </p>
            <p>
              Depuis nos débuts, nous avons à cœur de maintenir des liens étroits avec notre
              communauté locale. Chaque jour, nous sélectionnons avec soin nos produits pour vous
              offrir le meilleur de la région et de la gastronomie française.
            </p>
            <p>
              Notre sandwicherie propose des recettes maison préparées quotidiennement avec des
              ingrédients frais, tandis que notre épicerie vous permet de trouver tous les
              produits essentiels du quotidien.
            </p>
          </div>
        </section>

        {/* Nos Valeurs */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center text-primary">Nos Valeurs</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-card rounded-xl">
              <Heart className="h-16 w-16 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-bold mb-3">Passion</h3>
              <p className="text-muted-foreground">
                L'amour du bon produit et du service client au cœur de notre métier
              </p>
            </div>
            <div className="text-center p-6 bg-card rounded-xl">
              <Users className="h-16 w-16 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-bold mb-3">Proximité</h3>
              <p className="text-muted-foreground">
                Un commerce de quartier accessible et à l'écoute de ses clients
              </p>
            </div>
            <div className="text-center p-6 bg-card rounded-xl">
              <Award className="h-16 w-16 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-bold mb-3">Qualité</h3>
              <p className="text-muted-foreground">
                Des produits soigneusement sélectionnés pour leur fraîcheur et leur goût
              </p>
            </div>
          </div>
        </section>

        {/* Notre Mission */}
        <section className="max-w-4xl mx-auto bg-muted/30 p-8 rounded-xl">
          <h2 className="text-3xl font-bold mb-6 text-primary">Notre Mission</h2>
          <p className="text-lg text-muted-foreground mb-4">
            Chez SNCBOISSET, notre mission est simple : offrir à nos clients une expérience
            d'achat agréable avec des produits de qualité à des prix justes.
          </p>
          <p className="text-lg text-muted-foreground">
            Nous nous engageons à maintenir des relations durables avec nos fournisseurs locaux,
            à proposer des préparations maison savoureuses et à créer un lieu convivial où chacun
            se sent le bienvenu.
          </p>
        </section>
      </div>
    </div>
  );
};

export default About;
