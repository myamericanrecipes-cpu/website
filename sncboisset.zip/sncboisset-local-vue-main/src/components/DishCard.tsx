import { Card, CardContent } from "@/components/ui/card";

interface DishCardProps {
  image: string;
  name: string;
  description: string;
  price: string;
}

const DishCard = ({ image, name, description, price }: DishCardProps) => {
  return (
    <Card className="overflow-hidden hover-lift hover:shadow-lg transition-all">
      <div className="aspect-[4/3] overflow-hidden">
        <img
          src={image}
          alt={name}
          className="w-full h-full object-cover transition-transform hover:scale-105"
        />
      </div>
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-foreground">{name}</h3>
          <span className="text-lg font-semibold text-primary">{price}</span>
        </div>
        <p className="text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  );
};

export default DishCard;
