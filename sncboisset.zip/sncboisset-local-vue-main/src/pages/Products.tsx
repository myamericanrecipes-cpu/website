import ProductCard from "@/components/ProductCard";
import groceryImg from "@/assets/grocery-products.jpg";

const Products = () => {
  const freshProducts = [
    {
      image: groceryImg,
      name: "Fruits & Légumes",
      description: "Produits frais de saison, sélectionnés quotidiennement",
    },
    {
      image: groceryImg,
      name: "Produits Laitiers",
      description: "Fromages, yaourts et produits laitiers de qualité",
    },
    {
      image: groceryImg,
      name: "Viandes & Charcuterie",
      description: "Sélection de viandes et charcuteries artisanales",
    },
  ];

  const dryProducts = [
    {
      image: groceryImg,
      name: "Épicerie Salée",
      description: "Pâtes, riz, conserves et produits de base",
    },
    {
      image: groceryImg,
      name: "Épicerie Sucrée",
      description: "Biscuits, chocolats, confitures artisanales",
    },
    {
      image: groceryImg,
      name: "Condiments & Sauces",
      description: "Huiles, vinaigres, sauces et épices",
    },
  ];

  const drinks = [
    {
      image: groceryImg,
      name: "Boissons Fraîches",
      description: "Jus de fruits, sodas et eaux minérales",
    },
    {
      image: groceryImg,
      name: "Boissons Chaudes",
      description: "Café, thé et chocolat chaud de qualité",
    },
    {
      image: groceryImg,
      name: "Vins & Spiritueux",
      description: "Sélection de vins régionaux et spiritueux",
    },
  ];

  return (
    <div className="min-h-screen pt-28 pb-20">
      <div className="container mx-auto px-4">
        <h1 className="text-5xl font-bold text-center mb-4 text-foreground">
          Produits d'Épicerie
        </h1>
        <p className="text-center text-muted-foreground mb-12 text-lg">
          Une sélection de produits frais et de qualité pour tous vos besoins
        </p>

        {/* Produits Frais */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-primary">Produits Frais</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {freshProducts.map((item, index) => (
              <ProductCard key={index} {...item} />
            ))}
          </div>
        </section>

        {/* Épicerie Sèche */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-primary">Épicerie Sèche</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {dryProducts.map((item, index) => (
              <ProductCard key={index} {...item} />
            ))}
          </div>
        </section>

        {/* Boissons */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-primary">Boissons</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {drinks.map((item, index) => (
              <ProductCard key={index} {...item} />
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Products;
