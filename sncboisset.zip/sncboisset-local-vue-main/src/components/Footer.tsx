import { Phone, Mail, MapPin, Facebook, Instagram } from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground mt-20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Contact Info */}
          <div>
            <h3 className="text-xl font-bold mb-4">Contact</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                <a href="tel:+33644654596" className="hover:underline">
                  +33 6 44 65 45 96
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                <a href="mailto:contact@sncboisset.shop" className="hover:underline">
                  contact@sncboisset.shop
                </a>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-4">Liens rapides</h3>
            <div className="space-y-2">
              <Link to="/menu" className="block hover:underline">
                Menu & Plats
              </Link>
              <Link to="/produits" className="block hover:underline">
                Produits d'épicerie
              </Link>
              <Link to="/a-propos" className="block hover:underline">
                À propos
              </Link>
              <Link to="/contact" className="block hover:underline">
                Contact
              </Link>
            </div>
          </div>

          {/* Social Media */}
          <div>
            <h3 className="text-xl font-bold mb-4">Suivez-nous</h3>
            <div className="flex gap-4">
              <a
                href="#"
                className="hover:opacity-80 transition-opacity"
                aria-label="Facebook"
              >
                <Facebook className="h-6 w-6" />
              </a>
              <a
                href="#"
                className="hover:opacity-80 transition-opacity"
                aria-label="Instagram"
              >
                <Instagram className="h-6 w-6" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 mt-8 pt-8 text-center">
          <p className="text-sm">
            © {new Date().getFullYear()} SNCBOISSET – Votre commerce local à Épinal
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
