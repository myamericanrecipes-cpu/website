import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Heart, Leaf, MapPin } from "lucide-react";
import heroImage from "@/assets/hero-home.jpg";
import sandwichesImg from "@/assets/sandwiches.jpg";
import saladsImg from "@/assets/salads.jpg";
import groceryImg from "@/assets/grocery-products.jpg";
import DishCard from "@/components/DishCard";
import TestimonialCard from "@/components/TestimonialCard";

const Home = () => {
  const specialties = [
    {
      image: sandwichesImg,
      name: "Sandwichs Maison",
      description: "Baguettes fraîches garnies avec des ingrédients de qualité",
      price: "5,50€",
    },
    {
      image: saladsImg,
      name: "Salades Fraîches",
      description: "Compositions variées avec des légumes de saison",
      price: "7,00€",
    },
    {
      image: groceryImg,
      name: "Produits Locaux",
      description: "Une sélection de produits régionaux et artisanaux",
      price: "Variable",
    },
  ];

  const testimonials = [
    {
      text: "Toujours un accueil chaleureux et des sandwichs délicieux !",
      author: "Marie L.",
    },
    {
      text: "Une épicerie de quartier comme on les aime. Produits frais et de qualité.",
      author: "Jean-Pierre M.",
    },
    {
      text: "Le meilleur endroit pour un déjeuner rapide et savoureux à Épinal.",
      author: "Sophie D.",
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/30" />
        </div>
        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 animate-fade-in">
            Bienvenue chez SNCBOISSET
          </h1>
          <p className="text-xl md:text-2xl mb-8 animate-fade-in">
            Épicerie & restauration de proximité
          </p>
          <p className="text-lg md:text-xl mb-10 animate-fade-in">
            Produits frais, sandwichs maison, esprit local.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in">
            <Link to="/menu">
              <Button size="lg" className="text-lg px-8">
                Voir le menu
              </Button>
            </Link>
            <Link to="/produits">
              <Button size="lg" variant="secondary" className="text-lg px-8">
                Découvrir nos produits
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Nos Spécialités */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-12 text-foreground">
            Nos Spécialités
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {specialties.map((item, index) => (
              <DishCard key={index} {...item} />
            ))}
          </div>
        </div>
      </section>

      {/* Pourquoi nous choisir */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-12 text-foreground">
            Pourquoi nous choisir ?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <MapPin className="h-16 w-16 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-bold mb-3">Proximité</h3>
              <p className="text-muted-foreground">
                Un commerce de quartier accessible et convivial à Épinal
              </p>
            </div>
            <div className="text-center p-6">
              <Heart className="h-16 w-16 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-bold mb-3">Qualité</h3>
              <p className="text-muted-foreground">
                Des produits sélectionnés avec soin pour leur fraîcheur
              </p>
            </div>
            <div className="text-center p-6">
              <Leaf className="h-16 w-16 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-bold mb-3">Fraîcheur</h3>
              <p className="text-muted-foreground">
                Préparations quotidiennes avec des ingrédients frais
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Témoignages */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-12 text-foreground">
            Avis de nos clients
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <TestimonialCard key={index} {...testimonial} />
            ))}
          </div>
        </div>
      </section>

      {/* Contact & Horaires */}
      <section className="py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-8 text-foreground">
            Venez nous rendre visite
          </h2>
          <div className="max-w-2xl mx-auto space-y-6">
            <div>
              <h3 className="text-xl font-semibold mb-2">Contact</h3>
              <p className="text-muted-foreground">Téléphone : +33 6 44 65 45 96</p>
              <p className="text-muted-foreground">Email : contact@sncboisset.shop</p>
            </div>
            <Link to="/contact">
              <Button size="lg" className="mt-6">
                Nous contacter
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
