import DishCard from "@/components/DishCard";
import sandwichesImg from "@/assets/sandwiches.jpg";
import saladsImg from "@/assets/salads.jpg";

const Menu = () => {
  const sandwiches = [
    {
      image: sandwichesImg,
      name: "Le Classique",
      description: "Jambon, beurre, cornichons sur baguette fraîche",
      price: "4,50€",
    },
    {
      image: sandwichesImg,
      name: "Le Complet",
      description: "Jambon, fromage, salade, tomates, œuf",
      price: "5,80€",
    },
    {
      image: sandwichesImg,
      name: "Le Végétarien",
      description: "Houmous, légumes grillés, roquette, tomates séchées",
      price: "5,50€",
    },
    {
      image: sandwichesImg,
      name: "Le Poulet Curry",
      description: "Poulet mariné au curry, salade, carottes râpées",
      price: "6,00€",
    },
  ];

  const salads = [
    {
      image: saladsImg,
      name: "Salade Composée",
      description: "Salade verte, tomates, concombre, œuf, thon",
      price: "7,00€",
    },
    {
      image: saladsImg,
      name: "Salade César",
      description: "Poulet grillé, croûtons, parmesan, sauce césar",
      price: "7,50€",
    },
    {
      image: saladsImg,
      name: "Salade Chèvre Chaud",
      description: "Chèvre chaud, miel, noix, mesclun",
      price: "8,00€",
    },
  ];

  const wraps = [
    {
      image: sandwichesImg,
      name: "Wrap Poulet",
      description: "Poulet grillé, crudités, sauce blanche",
      price: "5,50€",
    },
    {
      image: sandwichesImg,
      name: "Wrap Végétal",
      description: "Falafels, houmous, légumes grillés",
      price: "5,50€",
    },
  ];

  const snacks = [
    {
      image: sandwichesImg,
      name: "Croque-Monsieur",
      description: "Jambon, fromage, pain de mie grillé",
      price: "4,00€",
    },
    {
      image: sandwichesImg,
      name: "Panini Jambon-Fromage",
      description: "Panini chaud garni jambon et fromage",
      price: "4,50€",
    },
  ];

  return (
    <div className="min-h-screen pt-28 pb-20">
      <div className="container mx-auto px-4">
        <h1 className="text-5xl font-bold text-center mb-4 text-foreground">Menu & Plats</h1>
        <p className="text-center text-muted-foreground mb-12 text-lg">
          Découvrez nos préparations maison avec des produits frais
        </p>

        {/* Sandwiches */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-primary">Sandwichs</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {sandwiches.map((item, index) => (
              <DishCard key={index} {...item} />
            ))}
          </div>
        </section>

        {/* Salades */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-primary">Salades</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {salads.map((item, index) => (
              <DishCard key={index} {...item} />
            ))}
          </div>
        </section>

        {/* Wraps */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-primary">Wraps</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {wraps.map((item, index) => (
              <DishCard key={index} {...item} />
            ))}
          </div>
        </section>

        {/* Snacks */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-primary">Snacks</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {snacks.map((item, index) => (
              <DishCard key={index} {...item} />
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Menu;
