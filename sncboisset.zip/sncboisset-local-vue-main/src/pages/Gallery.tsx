import sandwichesImg from "@/assets/sandwiches.jpg";
import saladsImg from "@/assets/salads.jpg";
import groceryImg from "@/assets/grocery-products.jpg";
import aboutImg from "@/assets/about-store.jpg";
import heroImg from "@/assets/hero-home.jpg";

const Gallery = () => {
  const images = [
    { src: heroImg, alt: "Nos produits frais" },
    { src: sandwichesImg, alt: "Sandwichs maison" },
    { src: saladsImg, alt: "Salades fraîches" },
    { src: groceryImg, alt: "Produits d'épicerie" },
    { src: aboutImg, alt: "Intérieur du magasin" },
    { src: sandwichesImg, alt: "Spécialités du jour" },
  ];

  return (
    <div className="min-h-screen pt-28 pb-20">
      <div className="container mx-auto px-4">
        <h1 className="text-5xl font-bold text-center mb-4 text-foreground">Galerie Photos</h1>
        <p className="text-center text-muted-foreground mb-12 text-lg">
          Découvrez nos produits, notre magasin et notre ambiance
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {images.map((image, index) => (
            <div
              key={index}
              className="aspect-square overflow-hidden rounded-xl shadow-lg hover-lift hover:shadow-xl transition-all"
            >
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-full object-cover transition-transform hover:scale-105"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Gallery;
