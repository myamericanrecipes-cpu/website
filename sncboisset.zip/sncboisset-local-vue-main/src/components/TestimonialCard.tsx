import { Card, CardContent } from "@/components/ui/card";
import { Quote } from "lucide-react";

interface TestimonialCardProps {
  text: string;
  author: string;
}

const TestimonialCard = ({ text, author }: TestimonialCardProps) => {
  return (
    <Card className="hover-lift hover:shadow-lg transition-all">
      <CardContent className="p-6">
        <Quote className="h-8 w-8 text-primary mb-4 opacity-50" />
        <p className="text-foreground mb-4 italic">{text}</p>
        <p className="text-sm font-semibold text-muted-foreground">— {author}</p>
      </CardContent>
    </Card>
  );
};

export default TestimonialCard;
