import TestimonialCard from "@/components/TestimonialCard";

const Testimonials = () => {
  const testimonials = [
    {
      text: "Toujours un accueil chaleureux et des sandwichs délicieux ! C'est devenu mon arrêt obligatoire à midi.",
      author: "Marie L.",
    },
    {
      text: "Une épicerie de quartier comme on les aime. Produits frais et de qualité, avec un vrai service de proximité.",
      author: "Jean-Pierre M.",
    },
    {
      text: "Le meilleur endroit pour un déjeuner rapide et savoureux à Épinal. Les salades sont excellentes !",
      author: "Sophie D.",
    },
    {
      text: "Des produits locaux, une équipe sympathique, et toujours de bons conseils. Je recommande vivement !",
      author: "Thomas B.",
    },
    {
      text: "J'apprécie particulièrement la fraîcheur des produits et l'ambiance conviviale du magasin.",
      author: "Claire R.",
    },
    {
      text: "Un commerce familial qui fait la différence dans notre quartier. Longue vie à SNCBOISSET !",
      author: "Pierre L.",
    },
  ];

  return (
    <div className="min-h-screen pt-28 pb-20">
      <div className="container mx-auto px-4">
        <h1 className="text-5xl font-bold text-center mb-4 text-foreground">
          Témoignages Clients
        </h1>
        <p className="text-center text-muted-foreground mb-12 text-lg">
          Ce que nos clients disent de nous
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} {...testimonial} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Testimonials;
